import requests
import csv
from bs4 import BeautifulSoup

url = 'https://www.amazon.com/best-sellers-books-Amazon/zgbs/books/'
# print(url)
bookinfo_list = []
for i in range(1, 6):
    url_page = url + "ref=zg_bs_pg_2?ie=UTF8&pg=" + str(i)
    r = requests.get(url_page)
    html = r.text
    # parsing into the beautiful soup
    soup = BeautifulSoup(html, "html.parser")
    # to get the books part of the website
    name_bestseller = soup.find_all('div', {'class': 'zg_itemImmersion'})
    # to print each and every book
    for name in name_bestseller:
        var = name.contents[3].find_all('a', {'class': 'a-link-normal'})
        try:
            b_name = var[0].text.strip()
        except:
            b_name = "Not available"
        try:
            url_book = var[0].get("href")
            b_addr = "https://www.amazon.com" + url_book
        except:
            b_addr = "Not available"
        try:
            b_aut = name.contents[3].find_all(
                    'div', {
                            'class': 'a-row a-size-small'
                           }
                                             )[0].text.strip()
        except:
            b_aut = "Not available"
    # var = nam.contents[3].find_all('a',{'class':'a-link-normal'})
        try:
            var1 = name.select('.p13n-sc-price')
            b_price = var1[0].text.strip()
        except:
            b_price = "Not available"
        try:
            var3 = name.select('.a-icon-star')[0].text.strip()
            b_avgr = var3
            b_numrat = var[2].text.strip()
        except:
            b_avgr = "Not available"
            b_numrat = "Not available"
        bookinfo = [b_name, b_addr, b_aut, b_price, b_numrat, b_avgr]
        bookinfo_list.append(bookinfo)
name_list = ['Name', 'URL', 'Author',
             'Price', 'Number of Ratings', 'Average Rating']
with open('./output/com_book.csv', 'w') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(name_list)
    for row in bookinfo_list:
            writer.writerow(row)
