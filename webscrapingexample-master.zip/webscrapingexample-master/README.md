# webscrapingexample
These example codes are for scrapping from amazon.in and amazon.com bestsellerbooks full details
